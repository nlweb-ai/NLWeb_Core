
export AZURE_VECTOR_SEARCH_ENDPOINT="https://nlweb-vector-search.search.windows.net"
export AZURE_VECTOR_SEARCH_API_KEY="MVg7SU4R9b3CRIcAabgab0t162ZGcoV5shYs0KXav9AzSeCUSlkg"


export AZURE_VECTOR_SEARCH_ENDPOINT_TEST="https://nlweb-vector-search-test.search.windows.net"
export AZURE_VECTOR_SEARCH_API_KEY_TEST="fyjhtf0FPpJCMOBTo1lXggIrj69VzeYWr8lSOYLAQmAzSeA96VEi"

export AZURE_OPENAI_ENDPOINT="https://yoastoai.openai.azure.com/"
export AZURE_OPENAI_API_KEY="37q9koLq3dLo4cpSkzdcNANqoJ32fZzD5g2qa9MxdhLawlptptSpJQQJ99BKAC4f1cMXJ3w3AAABACOGhvwY"

export AZURE_SEARCH_ENDPOINT="https://yoast-vector-db.search.windows.net"
export AZURE_SEARCH_API_KEY="ZcYXGAgtS5QaB64KKBTb9EQUtmEUvkLwILM2BoGoS0AzSeCGBWFx"

export INCEPTION_API_KEY="sk_20acbc0c79237170bb5683a70c40711b"

export ANTHROPIC_API_KEY="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"
export OPENAI_API_KEY="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"

export OPENAI_API_KEY="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"

export SWEDEN_API_KEY="A4EuhfNYKuRY5Uhc2MApM74lELj4r1acUMbel1CQMORaYq6OTgsMJQQJ99BEACfhMk5XJ3w3AAAAACOG6Y39"
export SWEDEN_ENDPOINT="https://sc-in-mab3js33-swedencentral.services.ai.azure.com/"
 

# NLWeb West endpoint variables for config_retrieval.yaml
export NLWEB_WEST_ENDPOINT="https://nlw-crawl-west.search.windows.net"
export NLWEB_WEST_API_KEY="m5dkvTBhDF0n7geXtAhywjYhTc7QFELMZTCYtgzH72AzSeDPi0zX"

# OpenSearch local instance
export OPENSEARCH_ENDPOINT="http://localhost:9200"
export OPENSEARCH_CREDENTIALS="admin:admin"

export BING_SEARCH_API_KEY="B30A330127C50C2C84DA51AF2F70256BE5C8FC40"
export BING_SEARCH_ENDPOINT="https://www.bingapis.com/api/v7/search"

export MAHI_PODCASTS_API_KEY="NCwTWdTBNNl1cUU2Jujcjd3Ri2Txsi2q7a8GVGNjnzAzSeCGog9V"
export MAHI_PODCASTS_ENDPOINT="https://npr-podcasts-db.search.windows.net"

export GOOGLE_MAPS_API_KEY="AIzaSyCsLcV73oXRXh0D-AeA7m6VjBq7Bmh4zRU"

export GOOGLE_AUTH_CLIENT_ID="666080977341-vsufbpjfe4kejsgndaahorb4a1sofq1l.apps.googleusercontent.com"
export GOOGLE_AUTH_CLIENT_SECRET="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"

export GITHUB_CLIENT_ID="Ov23li7Ph0lJDeA3xdLi"
export GITHUB_CLIENT_SECRET="8d689c574e09457d9cd1536c434970e58fd1d3bd"

# OAuth-specific environment variables
export GITHUB_OAUTH_CLIENT_ID="Ov23li7Ph0lJDeA3xdLi"
export GITHUB_OAUTH_CLIENT_SECRET="8d689c574e09457d9cd1536c434970e58fd1d3bd"

# OAuth Session Secret
export OAUTH_SESSION_SECRET="GBPOVmLpF3_AFvU_rjaTu7EuJ9bvo6VPhqm7IjGzc7g"

#export AZURE_VECTOR_SEARCH_ENDPOINT="https://maba-db.search.windows.net"
#export AZURE_VECTOR_SEARCH_API_KEY="yjTWjmy7JyyK7B3i76NrtoSKOfFUB7fSHkGOsGCOFPAzSeBZcIVI"

export BING_API_KEY="B30A330127C50C2C84DA51AF2F70256BE5C8FC40"

export GEMINI_API_KEY="AIzaSyCNVzjfFZeyu712_2ohFXP9mvTgmeI9evQ"

export PI_LABS_KEY="sk_9b186c889366466baa4bf7b5a8b694bc"

export NLWEB_BASE_URL="https://nlwm.azurewebsites.net/"